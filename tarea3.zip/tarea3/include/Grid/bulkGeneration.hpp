#ifndef BUlKGENERATION_HPP
#define BUlKGENERATION_HPP

#include <string>

using namespace std;

void bulkGenerateGrids(int n_start, int n_end, int n_step, string baseFilename);
void bulkGenerateGrids(string baseFilename);

#endif
