#ifndef RANDOMIZED_HPP
#define RANDOMIZED_HPP

#include "Grid/Grid.hpp"

using namespace std;

float closestPairRandomized(const Grid &grid);

#endif // RANDOMIZED_HPP
